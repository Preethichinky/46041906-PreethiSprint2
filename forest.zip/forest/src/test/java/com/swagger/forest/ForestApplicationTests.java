package com.swagger.forest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForestApplicationTests {

	@Test
	void contextLoads() {
	}

}
