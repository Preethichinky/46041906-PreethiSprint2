package com.swagger.forest.validations;

public class SchedulerValidations {

	public static String contactregex="[0-9]{10}";
}
